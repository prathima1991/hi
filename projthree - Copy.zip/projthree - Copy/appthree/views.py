from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def index(request):
    my_dict = {'inser_me':'Hello hi HELLO'}
    return render(request,'appthree/index.html',context=my_dict)


def contact(request):
    contact_dict = {'contact_list':'Here are the contact list'}
    return render(request,'appthree/contact.html',context=contact_dict)

def home(request):
    return render(request,'appthree/home.html')

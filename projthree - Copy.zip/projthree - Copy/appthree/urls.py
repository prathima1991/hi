from django.conf.urls import url
from appthree import views

app_name = 'appthree'


urlpatterns = [
    url(r'^$',views.index,name='index'),
    url(r'^$',views.contact,name='contact'),
    url(r'^$',views.home,name='home'),
]

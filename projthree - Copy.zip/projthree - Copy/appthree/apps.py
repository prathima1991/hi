from django.apps import AppConfig


class AppthreeConfig(AppConfig):
    name = 'appthree'
